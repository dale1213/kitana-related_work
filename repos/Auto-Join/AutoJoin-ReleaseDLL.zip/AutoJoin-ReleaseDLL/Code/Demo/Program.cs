﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.DataIntegration.AutoJoin.JoinGuru;
using System.Diagnostics;
using System.Threading;
using System.Runtime;
using System.Threading.Tasks;
using Microsoft.DataIntegration.AutoJoin.Common;


namespace Demo
{
    struct Parameter
    {
        // Parameters for table sampling
        public int SampleSize;

        // Parameters for split column (not in critical path)
        public bool EnableSplit;
        public double MinSplitSupport;

        // Parameters for key column detection
        public int MaxCompositeColumnSize;
        public double CompositeColumnSupportThreshold;

        // Parameters for row-level correspondences search
        public int MinQGramSize; // If this set to a small value (< 4), then we probably need to drop numerical columns to avoid false positives
        public QGramRowMatchMode QGramMatchMode; // Choose Recall for most cases.

        // Parameters for program composition
        public int MaxNumTopRowMatchPerColumnAlignedGroup;
        public int ExampleBatchSize;
        public int MaxNumExamplePerColumnAlignedGroup;
        public int MaxTotalNumTransformationLearning;

        // Parameters for fuzzy join
        public bool EnableFuzzyJoin;
        public Func<IList<string>, IList<string>> Analyzer;
        public Func<ICollection<string>, ICollection<string>, double> SimFunc;

        // Parameters for dataset location
        public IList<string> CaseDirs;

        // For reading table and pre-processing
        public Func<string, Table> ReadTableFunc;

        // For output the detailed report in CSV format
        public string OutputFilename;

        // multi-processing or multi-threading
        public bool UseMultiProcess;
    }

    /// <summary>
    /// This executable is for demo the Join Guru algorithm. The structure is the
    /// same as the JoinGuruBenchmark.
    /// </summary>
    class Program
    {
        private static Parameter DemoBenchmarkParams = new Parameter
        {
            SampleSize = 50,
            EnableSplit = false,
            MaxCompositeColumnSize = 1,
            CompositeColumnSupportThreshold = 1.0,
            MinQGramSize = 3,
            QGramMatchMode = QGramRowMatchMode.Recall,
            MaxNumTopRowMatchPerColumnAlignedGroup = 6,
            // yeye: each group of io examples has this many rows
            ExampleBatchSize = 4, 
            // yeye: each col-aligned set can contribute at most this number of example sets
            MaxNumExamplePerColumnAlignedGroup = 16, // there is only one column alined group, since only one target column
            // yeye: in total we will try this many number of example sets
            MaxTotalNumTransformationLearning = 64, // so make these two parameter the same
            EnableFuzzyJoin = true,
            Analyzer = Analyzer.CreateMultiStringQGramAnalyzer(2),
            SimFunc = (a, b) => SimilarityFunction.Jaccard(a, b),
            CaseDirs = Directory.GetDirectories(@"..\..\..\..\DemoBenchmark\"),
            // N * p1 * p2 * p >= required_size, required=20, p=0.2, N=M=1M, p1 = 0.01 
            // N=size of smaller table, p1,p2=sampling rate of T1, T2, p=join participation rate of smaller table, required=number match required
            ReadTableFunc = f => Table.ReadCsv(f).DropLongTextColumns(64, 8, 0.01), // Table.ReadCsv(f, 0.01), // this is to subsample both input tables for more efficient indexing
            OutputFilename = @"..\..\..\..\DemoBenchmark\Output_DemoBenchmark.csv",
            UseMultiProcess = false
        };

        static void Main(string[] args)
        {

            //ThreadPool.SetMinThreads(64, 2);
            //GCSettings.LatencyMode = GCLatencyMode.SustainedLowLatency;
            Run(DemoBenchmarkParams);
        }

        // Parameters for pre-processing tables after loading it into memory
        private static double numericalColumnSupportThreshold = 0.3;
        private static double longTextColumnSupportThreshold = 0.5;
        private static int longTextColumnMinCharCount = 128;
        private static int longTextColumnMinWordCount = 32;

        private static Table loadTableWithDroppingColumns(string filename)
        {
            return Table.ReadCsv(filename)
                    .DropNumericalColumns(numericalColumnSupportThreshold)
                    .DropLongTextColumns(longTextColumnMinCharCount, longTextColumnMinWordCount, longTextColumnSupportThreshold);
        }

        private static void Run(Parameter param)
        {
            // load semantic join tables
            Stopwatch sw = new Stopwatch();



            var fuzzyResults = new List<EvaluationResult>();
            var equalityResults = new List<EvaluationResult>();
            var outputs = new List<string[]>();
            foreach (var caseDir in param.CaseDirs)
            {
                //if (!caseDir.Contains(@"state_abbrev"))
                //    continue;

                //if (Directory.GetFiles(caseDir).Length < 3)
                //{
                //    continue;
                //}
                var sourceFilename = Path.Combine(caseDir, "source.csv");
                var targetFilename = Path.Combine(caseDir, "target.csv");
                Console.WriteLine($"\nWorking on case: {caseDir}");

                // Index tables
                var transformationWorkerPath
                    = @".;D:\yeyehe\xcgdev\Users\YeyeHe\AutoJoin\Code\TransformationWorker\bin\Debug;..\..\..\TransformationWorker\bin\Debug";
                var guru = new JoinGuru("\u0000", "" /*transformationWorkerPath*/);
                Table table_1 = param.ReadTableFunc(sourceFilename);
                Table table_2 = param.ReadTableFunc(targetFilename);

                List<List<Tuple<string, string>>> semantic_join_results = new List<List<Tuple<string, string>>>();
                
                var stopWatch = new Stopwatch();
                stopWatch.Start();
                guru.Add(table_1);
                guru.Add(table_2);
                Console.WriteLine($"Table indexing took {stopWatch.Elapsed.TotalSeconds}");
                

                // Start GC at clean state
                //GC.WaitForFullGCComplete();

                //// Try to allocate enough memory to enter non-GC region
                //var allocated = GC.TryStartNoGCRegion(1024 * 1024 * 100, true);
                //if (!allocated)
                //{
                //    GC.EndNoGCRegion();
                //    throw new Exception("Not enough memory to start no-GC region");
                //}

                // Discover join path
                var joinGuruParam = new JoinGuruParameter
                {
                    MinQ = param.MinQGramSize,
                    MaxCompositeColumnSize = param.MaxCompositeColumnSize,
                    CompositeColumnSupportThreshold = param.CompositeColumnSupportThreshold,
                    NumRowMatch = param.MaxNumTopRowMatchPerColumnAlignedGroup,
                    MaxNumTry = param.MaxTotalNumTransformationLearning,
                    MaxNumExample = param.MaxNumExamplePerColumnAlignedGroup,
                    ExampleBatchSize = param.ExampleBatchSize,
                    ProbeTimeSampleSize = param.SampleSize,
                    QGramMatchMode = param.QGramMatchMode,
                    UseMultiProcess = param.UseMultiProcess
                };
                stopWatch.Restart();
                IList<JoinPath> paths = null;
                bool success;
                paths = guru.ComputeJoinPaths(joinGuruParam, out success);

                // this part is the non-critical path: for composite input columns, split to see if this produce joinable programs
                if (!success && param.EnableSplit)
                {
                    Console.WriteLine("Re-trying with split column for target.csv");
                    stopWatch.Stop();
                    guru.Clear();
                    guru.Add(param.ReadTableFunc(sourceFilename));
                    guru.Add(param.ReadTableFunc(targetFilename).SplitedColumns(param.MinSplitSupport).DropNumericalColumns(0.3));
                    stopWatch.Start();
                    paths = guru.ComputeJoinPaths(joinGuruParam, out success);
                    if (!success)
                    {
                        Console.WriteLine("Re-trying with split column for source.csv");
                        stopWatch.Stop();
                        guru.Clear();
                        guru.Add(param.ReadTableFunc(sourceFilename).SplitedColumns(param.MinSplitSupport).DropNumericalColumns(0.3));
                        guru.Add(param.ReadTableFunc(targetFilename));
                        stopWatch.Start();
                        paths = guru.ComputeJoinPaths(joinGuruParam, out success);
                    }
                }
                var discoverJoinPathTime = stopWatch.Elapsed.TotalSeconds;
                Console.WriteLine($"Discovering join paths took {discoverJoinPathTime}");

                //// Exit from no-GC region
                //GC.EndNoGCRegion();


                // Check if we have found a join path
                if (!success || paths.All(p => p.Score < 2))
                {
                    Console.WriteLine("Failed to find promising syntactic join path");
                    continue;
                }
                var path = paths.First();

                // Output the program
                var p_file = File.Open(Path.Combine(caseDir, "program.txt"), FileMode.Create);
                using (var f = new StreamWriter(p_file))
                {
                    var p = ((JoinGuruJoinPath)path).Transformations;
                    f.Write(string.Join("\n\n\n", p.Select(t => t.ToString())));
                }

                // Export program composition inputs and output
                var progCompDump = new Table("program composition dump",
                    path.SourceTable.GetColumns().Concat(
                        path.SourceMatchingColumn.Data.Select((values, j) => new Column(values, $"TRANSFORM_OUTPUT_{j}"))));
                progCompDump.SaveCsv(Path.Combine(caseDir, "program composition debug.csv"));

                // Output the examples used in program composition
                var p_ex_file = Path.Combine(caseDir, "program composition examples debug.csv");
                using (var f = new StreamWriter(p_ex_file))
                {
                    var jp = ((JoinGuruJoinPath)path);
                    for (var i = 0; i < jp.ExamplesUsed.Item1.Count; i++)
                    {
                        var line = new List<string>();
                        line.AddRange(jp.ExamplesUsed.Item1[i]);
                        line.AddRange(jp.ExamplesUsed.Item2[i]);
                        f.WriteLine(string.Join(",", line));
                    }
                }

                // Get tables
                var sourceTable = Table.ReadCsv(path.SourceTable.Name);
                var targetTable = Table.ReadCsv(path.TargetTable.Name);

                // Clean state
                GC.WaitForFullGCComplete();

                // Equality join
                stopWatch.Restart();
                var equalityRowMatches = TableJoin.EqualityJoinRowMatches(path.SourceMatchingColumn, path.TargetMatchingColumn);
                var equalityJoined = TableJoin.Join(sourceTable, targetTable, equalityRowMatches);
                var equalityJoinTime = stopWatch.Elapsed.TotalSeconds;
                Console.WriteLine($"Equality join took {equalityJoinTime}");
                equalityJoined.SaveCsv(Path.Combine(caseDir, "equality joined.csv"));

                // Load ground truth
                var groundTruth = Table.ReadCsv(Path.Combine(caseDir, "ground truth.csv"));

                // Evaluate equality join
                var equalityResult = new Evaluation(groundTruth).Evaluate(equalityJoined);
                Console.WriteLine($"Precision (equality join): {equalityResult.Precision}");
                Console.WriteLine($"Recall (equality join): {equalityResult.Recall}");
                equalityResults.Add(equalityResult);
                equalityResult.Correct.SaveCsv(Path.Combine(caseDir, "correct equality joined.csv"));
                equalityResult.Incorrect.SaveCsv(Path.Combine(caseDir, "incorrect equality joined.csv"));
                equalityResult.Missing.SaveCsv(Path.Combine(caseDir, "missing equality joined.csv"));

                // Clean state
                GC.WaitForFullGCComplete();

                // Fuzzy join
                var fuzzyJoinTime = 0.0;
                EvaluationResult fuzzyJoinResult = new EvaluationResult { Precision = 0.0, Recall = 0.0 };
                if (param.EnableFuzzyJoin)
                {
                    stopWatch.Restart();
                    var fuzzyGuru = new FuzzyJoinGuru(path.SourceMatchingColumn, path.TargetMatchingColumn, param.Analyzer);
                    double threshold;
                    IEnumerable<Match> rowMatches;
                    if (fuzzyGuru.OptimizeSimilarityThreshold(param.SimFunc, 0.05, out threshold))
                    {
                        Console.WriteLine($"Maximum Multiplicity is {fuzzyGuru.MaxMultiplicity}");
                        Console.WriteLine($"Optimal similarity threshold for fuzzy join is {threshold}");
                        rowMatches = TableJoin.FuzzyJoinThresholdRowMatches(path.SourceMatchingColumn, path.TargetMatchingColumn, param.Analyzer, param.SimFunc, threshold);
                    }
                    else
                    {
                        Console.WriteLine("Failed to find optimal similarity threshold, using best match instead");
                        rowMatches = TableJoin.FuzzyJoinBestMatchRowMatches(path.SourceMatchingColumn, path.TargetMatchingColumn, param.Analyzer, param.SimFunc);
                    }
                    var joined = TableJoin.Join(sourceTable, targetTable, rowMatches);
                    fuzzyJoinTime = stopWatch.Elapsed.TotalSeconds;
                    Console.WriteLine($"Fuzzy join took {fuzzyJoinTime}");
                    joined.SaveCsv(Path.Combine(caseDir, "joined.csv"));

                    //Evaluate Fuzzy Join
                    fuzzyJoinResult = new Evaluation(groundTruth).Evaluate(joined);
                    Console.WriteLine($"Precision (fuzzy join): {fuzzyJoinResult.Precision}");
                    Console.WriteLine($"Recall (fuzzy join): {fuzzyJoinResult.Recall}");
                    fuzzyResults.Add(fuzzyJoinResult);
                    fuzzyJoinResult.Correct.SaveCsv(Path.Combine(caseDir, "correct joined.csv"));
                    fuzzyJoinResult.Incorrect.SaveCsv(Path.Combine(caseDir, "incorrect joined.csv"));
                    fuzzyJoinResult.Missing.SaveCsv(Path.Combine(caseDir, "missing joined.csv"));
                }
                // Append to output
                outputs.Add(new[] { caseDir, equalityResult.Precision.ToString(), equalityResult.Recall.ToString(), fuzzyJoinResult.Precision.ToString(), fuzzyJoinResult.Recall.ToString(),
                    discoverJoinPathTime.ToString(), equalityJoinTime.ToString(), fuzzyJoinTime.ToString() });

            }

            // Write the detailed report to file
            var outputTable = new Table(param.OutputFilename, new[] { "Case", "Equality Join Precision", "Equality Join Recall", "Fuzzy Join Precision", "Fuzzy Join Recall",
                "Discover Join Path Time", "Equality Join Time", "Fuzzy Join Time" }, outputs);
            outputTable.SaveCsv(param.OutputFilename);



            Console.WriteLine("\n====Overall Report====:");
            Console.WriteLine($"Detailed report written to {param.OutputFilename}");
        }
    }
}